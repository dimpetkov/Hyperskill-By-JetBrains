public class Main {
    public static void main(String[] args) {
        // put your code here
        final int pr = 1996;
        System.out.println(pr);
    }
}